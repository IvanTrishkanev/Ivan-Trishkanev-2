from tkinter import *

root = Tk()
root.title("METANIT.COM")
root.geometry("300x250")

canvas = Canvas(bg="white", width=250, height=200)
canvas.pack(anchor=CENTER, expand=1)

canvas.create_polygon(10, 30, 200, 200, 200, 30, fill="#80CBC4", outline="#004D40")

root.mainloop()