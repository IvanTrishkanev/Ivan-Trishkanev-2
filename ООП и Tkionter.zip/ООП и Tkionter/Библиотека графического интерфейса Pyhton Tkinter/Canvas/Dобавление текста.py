from tkinter import *

root = Tk()
root.title("METANIT.COM")
root.geometry("300x250")

canvas = Canvas(bg="white", width=250, height=200)
canvas.pack(anchor=CENTER, expand=1)

canvas.create_text(50, 50, text="Hello METANIT.COM", fill="#004D40")
canvas.create_text(50, 100, anchor=NW, text="Hello METANIT.COM", fill="#004D40")

root.mainloop()