from tkinter import *

root = Tk()
root.title("METANIT.COM")
root.geometry("300x250")

canvas = Canvas(bg="white", width=250, height=200)
canvas.pack(anchor=CENTER, expand=1)

canvas.create_line(10, 10, 200, 50, activefill="red", fill="blue", dash=2)
canvas.create_line(10, 50, 200, 90, activefill="red", fill="blue", dash=2)

root.mainloop()