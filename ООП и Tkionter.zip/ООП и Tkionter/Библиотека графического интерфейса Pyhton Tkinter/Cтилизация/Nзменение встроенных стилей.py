from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

ttk.Style().configure("TLabel", font="helvetica 13", foreground="#004D40", padding=8, background="#B2DFDB")

ttk.Label(text="Hello World!").pack(anchor=NW, padx=6, pady=6)
ttk.Button(text="Click").pack(anchor=NW, padx=6, pady=6)

root.mainloop()