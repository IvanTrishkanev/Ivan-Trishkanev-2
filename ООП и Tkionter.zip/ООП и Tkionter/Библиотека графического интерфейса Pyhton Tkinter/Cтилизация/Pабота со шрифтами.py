from tkinter import *
from tkinter import ttk
from tkinter import font

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

font1 = font.Font(
    family="Arial", 
    size=11, 
    weight="normal", 
    slant="roman", 
    underline=True, 
    overstrike=True
)

label1 = ttk.Label(text="Hello World", font=font1)
label1.pack(anchor=NW)

for family in font.families():
    print(family)

root.mainloop()