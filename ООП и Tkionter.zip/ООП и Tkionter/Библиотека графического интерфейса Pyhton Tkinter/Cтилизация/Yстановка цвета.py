from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

label = ttk.Label(
    text="Hello World",
    padding=8,
    foreground="#01579B", 
    background="#B3E5FC"  
)
label.pack(anchor=CENTER, expand=1)

def get_rgb(rgb):
    return "#%02x%02x%02x" % rgb

label2 = ttk.Label(
    text="Hello World",
    padding=8,
    foreground=get_rgb((0, 77, 64)),    
    background=get_rgb((128, 203, 196)) 
)
label2.pack(anchor=CENTER, expand=1)

root.mainloop()