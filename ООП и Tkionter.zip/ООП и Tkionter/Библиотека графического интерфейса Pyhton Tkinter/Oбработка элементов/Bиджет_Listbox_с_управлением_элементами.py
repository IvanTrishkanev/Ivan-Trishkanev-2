from tkinter import *
from tkinter import ttk

def add_item():
    languages_listbox.insert(END, entry.get())

def delete_item():
    languages_listbox.delete(ACTIVE)

root = Tk()
root.title("METANIT.COM")
root.geometry("300x200")

languages_listbox = Listbox()
languages_listbox.pack(fill=BOTH, expand=True, padx=10, pady=10)

entry = ttk.Entry()
entry.pack(fill=X, padx=10)
ttk.Button(text="Добавить", command=add_item).pack(side=LEFT, padx=10)
ttk.Button(text="Удалить", command=delete_item).pack(side=LEFT)

root.mainloop()