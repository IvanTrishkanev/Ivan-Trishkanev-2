from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

frame = ttk.Frame(borderwidth=1, relief=SOLID, padding=10)
frame.pack(padx=10, pady=10, fill=BOTH, expand=True)

ttk.Label(frame, text="Имя:").pack(anchor=NW)
ttk.Entry(frame).pack(anchor=NW, fill=X)

root.mainloop()