from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

listbox = Listbox()
scrollbar = ttk.Scrollbar(orient="vertical", command=listbox.yview)
listbox.configure(yscrollcommand=scrollbar.set)

scrollbar.pack(side=RIGHT, fill=Y)
listbox.pack(side=LEFT, fill=BOTH, expand=True)

for i in range(1, 30):
    listbox.insert(END, f"Элемент {i}")

root.mainloop()