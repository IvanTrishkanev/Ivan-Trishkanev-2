from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

editor = Text()
editor.pack(expand=1, fill=BOTH)

def click():
    editor.insert("2.0", "Click\n")

btn = ttk.Button(editor, text="Click", command=click)
editor.window_create("1.0", window=btn)

root.mainloop()