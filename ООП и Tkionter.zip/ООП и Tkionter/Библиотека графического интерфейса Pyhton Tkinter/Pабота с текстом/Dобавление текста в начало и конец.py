from tkinter import *

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

editor = Text()
editor.pack(fill=BOTH, expand=1)

editor.insert("1.0", "Hello World") 
editor.insert(END, "\nBye World")    

root.mainloop()