from tkinter import *
from tkinter.scrolledtext import ScrolledText

root = Tk()
root.title("METANIT.COM")
root.geometry("250x150")

st = ScrolledText(root, width=50, height=10)
st.pack(fill=BOTH, side=LEFT, expand=True)

root.mainloop()