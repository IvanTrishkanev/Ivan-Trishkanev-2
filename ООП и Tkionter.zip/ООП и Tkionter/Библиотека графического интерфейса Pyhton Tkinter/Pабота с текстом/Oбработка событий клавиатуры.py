from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

def on_modified(event):
    label["text"] = editor.get("1.0", END)

editor = Text(height=8)
editor.pack(fill=X)
editor.bind("<KeyRelease>", on_modified)

label = ttk.Label()
label.pack(anchor=NW)

root.mainloop()