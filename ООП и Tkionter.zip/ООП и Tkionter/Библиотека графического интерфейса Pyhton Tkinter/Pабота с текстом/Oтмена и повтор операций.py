from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

root.grid_columnconfigure(0, weight=1)
root.grid_columnconfigure(1, weight=1)
root.grid_rowconfigure(0, weight=1)

editor = Text(undo=True)
editor.grid(column=0, columnspan=2, row=0, sticky=NSEW)

def undo(): editor.edit_undo()
def redo(): editor.edit_redo()

ttk.Button(text="Undo", command=undo).grid(column=0, row=1)
ttk.Button(text="Redo", command=redo).grid(column=1, row=1)

root.mainloop()