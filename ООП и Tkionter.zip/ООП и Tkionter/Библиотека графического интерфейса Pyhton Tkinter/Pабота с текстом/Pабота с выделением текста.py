from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

def get_selection():
    label["text"] = editor.selection_get()

def clear_selection():
    editor.selection_clear()

editor = Text(height=5)
editor.pack(fill=X)

label = ttk.Label()
label.pack(anchor=NW)

ttk.Button(text="Get selection", command=get_selection).pack(side=LEFT)
ttk.Button(text="Clear", command=clear_selection).pack(side=RIGHT)

root.mainloop()