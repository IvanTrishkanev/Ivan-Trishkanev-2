from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("300x200")

editor = Text(height=5)
editor.pack(anchor=N, fill=X)

label = ttk.Label()
label.pack(anchor=N, fill=BOTH)

def get_text():
    label["text"] = editor.get("1.0", "end")

ttk.Button(text="Click", command=get_text).pack(side=BOTTOM)

root.mainloop()