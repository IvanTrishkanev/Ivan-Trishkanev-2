from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("300x200")

editor = Text(height=10)
editor.pack(anchor=N, fill=BOTH)
editor.insert("1.0", "мама мыла раму")

def edit_text():
    editor.replace("1.0", "1.4", "дама")

ttk.Button(text="Replace", command=edit_text).pack(side=BOTTOM)

root.mainloop()