from tkinter import *
root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")
btn = Button(text="Click")
btn.pack()
root.mainloop()