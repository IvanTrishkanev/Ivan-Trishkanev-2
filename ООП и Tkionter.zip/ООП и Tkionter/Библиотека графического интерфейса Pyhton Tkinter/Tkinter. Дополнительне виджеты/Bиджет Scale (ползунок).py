from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x250")

vertical_scale = ttk.Scale(orient=VERTICAL, length=200, from_=1.0, to=100.0, value=50)
vertical_scale.pack()

horizontal_scale = ttk.Scale(orient=HORIZONTAL, length=200, from_=1.0, to=100.0, value=30)
horizontal_scale.pack()

root.mainloop()