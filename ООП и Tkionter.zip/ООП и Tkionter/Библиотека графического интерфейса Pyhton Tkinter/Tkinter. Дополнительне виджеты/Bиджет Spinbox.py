from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

spinbox = ttk.Spinbox(from_=1.0, to=100.0, increment=2, state="readonly")
spinbox.pack(anchor=NW)

root.mainloop()