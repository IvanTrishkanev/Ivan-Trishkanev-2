from tkinter import *

root = Tk()
root.title("METANIT.COM")
root.geometry("250x150")

main_menu = Menu()
main_menu.add_cascade(label="File")
main_menu.add_cascade(label="Edit")
main_menu.add_cascade(label="View")

root.config(menu=main_menu)
root.mainloop()