from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

notebook = ttk.Notebook()
notebook.pack(expand=True, fill=BOTH)

python_logo = PhotoImage(file=r"C:\Users\пк\Desktop\Metodichi\OOO and Tkinter\Code\Oбработка элементов\pepe.png")
java_logo = PhotoImage(file=r"C:\Users\пк\Desktop\Metodichi\OOO and Tkinter\Code\Oбработка элементов\jjj.png")

frame1 = ttk.Frame(notebook)
frame2 = ttk.Frame(notebook)

notebook.add(frame1, text="Python", image=python_logo, compound=LEFT)
notebook.add(frame2, text="Java", image=java_logo, compound=LEFT)

root.mainloop()