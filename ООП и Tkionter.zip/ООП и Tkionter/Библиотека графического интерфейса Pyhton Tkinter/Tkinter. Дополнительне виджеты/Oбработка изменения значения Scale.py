from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

def change(new_val):
    label["text"] = new_val  

label = ttk.Label()
label.pack(anchor=NW)

scale = ttk.Scale(
    orient=HORIZONTAL, 
    length=200, 
    from_=1.0, 
    to=100.0, 
    command=change
)
scale.pack(anchor=NW)

root.mainloop()