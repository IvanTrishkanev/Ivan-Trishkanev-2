from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x150")

progressbar = ttk.Progressbar(
    orient="horizontal", 
    mode="indeterminate", 
    length=200
)
progressbar.pack(pady=10)

ttk.Button(text="Start", command=progressbar.start).pack(side=LEFT, padx=10)
ttk.Button(text="Stop", command=progressbar.stop).pack(side=RIGHT, padx=10)

root.mainloop()