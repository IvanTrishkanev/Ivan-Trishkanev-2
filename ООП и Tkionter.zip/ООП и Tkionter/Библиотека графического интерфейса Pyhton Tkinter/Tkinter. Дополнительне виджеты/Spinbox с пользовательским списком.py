from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x150")

languages = ["Python", "JavaScript", "C#", "Java", "C++"]
spinbox = ttk.Spinbox(values=languages, state="readonly")
spinbox.pack(anchor=NW)

root.mainloop()