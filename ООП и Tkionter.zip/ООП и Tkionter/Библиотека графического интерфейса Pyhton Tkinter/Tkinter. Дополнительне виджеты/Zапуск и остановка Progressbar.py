from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x150")

def start():
    progressbar.start(1000)  

def stop():
    progressbar.stop()

progressbar = ttk.Progressbar(orient="horizontal", length=200)
progressbar.pack(pady=10)

ttk.Button(text="Start", command=start).pack(side=LEFT, padx=10)
ttk.Button(text="Stop", command=stop).pack(side=RIGHT, padx=10)

root.mainloop()