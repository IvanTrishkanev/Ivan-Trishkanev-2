import customtkinter

class ScrollableCheckboxFrame(customtkinter.CTkFrame):
    def __init__(self, master, values, title=None, height=100):
        super().__init__(master)
        self.values = values
        self.checkboxes = []

        self.scroll_frame = customtkinter.CTkScrollableFrame(self, height=height)
        self.scroll_frame.grid(row=1, column=0, sticky="nsew")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        if title:
            self.title_label = customtkinter.CTkLabel(self, text=title, fg_color="gray30", corner_radius=6)
            self.title_label.grid(row=0, column=0, padx=10, pady=(10, 0), sticky="ew")
 
        for i, value in enumerate(self.values):
            checkbox = customtkinter.CTkCheckBox(self.scroll_frame, text=value)
            checkbox.grid(row=i, column=0, padx=10, pady=(10, 0), sticky="w")
            self.checkboxes.append(checkbox)

    def get(self):
        checked_checkboxes = []
        for checkbox in self.checkboxes:
            if checkbox.get() == 1:
                checked_checkboxes.append(checkbox.cget("text"))
        return checked_checkboxes

class App(customtkinter.CTk):
    def __init__(self):
        super().__init__()
        self.title("Scrollable Checkbox Frame Example")
        self.geometry("400x300")

        values = [f"Option {i+1}" for i in range(20)]

        self.scrollable_frame = ScrollableCheckboxFrame(self, values=values, title="Select Options", height=200)
        self.scrollable_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")

        self.button = customtkinter.CTkButton(self, text="Get Selected", command=self.button_callback)
        self.button.grid(row=1, column=0, padx=10, pady=10, sticky="ew")

    def button_callback(self):
        print("Selected options:", self.scrollable_frame.get())

app = App()
app.mainloop()