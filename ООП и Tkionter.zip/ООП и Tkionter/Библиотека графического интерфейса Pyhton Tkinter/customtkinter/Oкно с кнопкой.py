import customtkinter

def button_callback():
    print("button pressed")

app = customtkinter.CTk()
app.title("my app")
app.geometry("400x180")

button = customtkinter.CTkButton(
    app, 
    text="my button", 
    command=button_callback,
    fg_color="#3B8ED0",  
    hover_color="#1F6AA5",  
    text_color="white",  
)
button.pack(pady=20, padx=30)

app.mainloop()