from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

python_logo = PhotoImage(file=r"C:\Users\LockPlay\Desktop\Методичка\Разработка_графического_приложения\Обработка событий\93d8945b0e64404ae92b547edd6a36c8.png")
label = ttk.Label(image=python_logo, text="Python", compound="top")
label.pack()

root.mainloop()