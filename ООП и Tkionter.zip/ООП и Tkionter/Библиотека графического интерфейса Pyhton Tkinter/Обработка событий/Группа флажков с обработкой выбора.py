from tkinter import *
from tkinter import ttk

def select():
    selected = []
    if python.get(): selected.append("Python")
    if javascript.get(): selected.append("JavaScript")
    if java.get(): selected.append("Java")
    languages.set("Выбрано: " + ", ".join(selected))

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

languages = StringVar()
position = {"padx":6, "pady":6, "anchor":NW}

ttk.Label(textvariable=languages).pack(**position)

python = IntVar()
ttk.Checkbutton(text="Python", variable=python, command=select).pack(**position)

javascript = IntVar()
ttk.Checkbutton(text="JavaScript", variable=javascript, command=select).pack(**position)

java = IntVar()
ttk.Checkbutton(text="Java", variable=java, command=select).pack(**position)

root.mainloop()