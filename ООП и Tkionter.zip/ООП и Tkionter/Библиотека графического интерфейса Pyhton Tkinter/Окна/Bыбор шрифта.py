from tkinter import *
from tkinter import ttk

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

label = ttk.Label(text="Пример текста")
label.pack()

def select_font():
    root.tk.call("tk", "fontchooser", "show")

ttk.Button(text="Выбрать шрифт", command=select_font).pack()
root.mainloop()