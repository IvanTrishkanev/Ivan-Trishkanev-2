from tkinter import *
from tkinter import ttk
from tkinter.messagebox import showinfo, showwarning, showerror

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

ttk.Button(text="Информация", command=lambda: showinfo("Информация", "Сообщение")).pack()
ttk.Button(text="Предупреждение", command=lambda: showwarning("Внимание!", "Осторожно!")).pack()
ttk.Button(text="Ошибка", command=lambda: showerror("Ошибка", "Что-то сломалось")).pack()
root.mainloop()