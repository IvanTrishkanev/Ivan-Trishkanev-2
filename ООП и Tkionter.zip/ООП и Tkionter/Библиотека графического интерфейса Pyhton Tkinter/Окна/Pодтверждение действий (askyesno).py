from tkinter import *
from tkinter import ttk
from tkinter.messagebox import askyesno, showinfo

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

def confirm():
    result = askyesno("Подтверждение", "Вы уверены?")
    showinfo("Результат", "Да" if result else "Нет")

ttk.Button(text="Подтвердить", command=confirm).pack(anchor=CENTER, expand=1)
root.mainloop()