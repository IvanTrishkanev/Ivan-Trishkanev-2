from tkinter import *
from tkinter import ttk
from tkinter.messagebox import showinfo

root = Tk()
root.title("METANIT.COM")
root.geometry("250x200")

ttk.Button(
    text="Сообщение",
    command=lambda: showinfo(
        title="Пример",
        message="Основной текст",
        detail="Дополнительная информация",
        icon="info"
    )
).pack()
root.mainloop()