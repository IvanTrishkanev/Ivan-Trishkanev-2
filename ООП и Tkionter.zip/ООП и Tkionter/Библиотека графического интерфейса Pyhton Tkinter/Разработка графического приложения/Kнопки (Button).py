from tkinter import *

root = Tk()
root.title("Мое первое приложение")  
root.geometry("400x300")            

label = Label(root, text="Привет, Tkinter!", font=("Arial", 14))
label.pack(pady=20)  

def button_click():
    print("Кнопка нажата!")
    
btn = Button(root, text="Нажми меня", command=button_click)
btn.pack(pady=10)

root.mainloop()