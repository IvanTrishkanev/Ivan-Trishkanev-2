from tkinter import *

root = Tk()
root.title("Мое первое приложение")  
root.geometry("400x300")            

label = Label(root, text="Привет, Tkinter!", font=("Arial", 14))
label.pack(pady=20)  

entry = Entry(root, width=30)
entry.pack(pady=10)

def get_text():
    print("Введенный текст:", entry.get())

btn_get = Button(root, text="Получить текст", command=get_text)
btn_get.pack()

root.mainloop()
