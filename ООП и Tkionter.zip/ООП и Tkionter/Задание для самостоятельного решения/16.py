class Wizard:
    def __init__(self, name, rating, apparent_age):
        self.name = name
        self.rating = min(max(1, rating), 100)
        self.apparent_age = max(18, apparent_age)
    def change_rating(self, value):
        new_rating = self.rating + value
        self.rating = min(max(1, new_rating), 100)  
        age_change = abs(value) // 10
        if value > 0:
            self.apparent_age = max(18, self.apparent_age - age_change)
        else:
            self.apparent_age += age_change
    def __iadd__(self, string):
        length = len(string)
        self.change_rating(length)
        return self
    def __call__(self, number):
        return (number - self.apparent_age) * self.rating
    def __str__(self):
        return f"Wizard {self.name} with {self.rating} rating looks {self.apparent_age} years old"
    def __eq__(self, other):
        if not isinstance(other, Wizard):
            return NotImplemented
        return (self.rating, self.apparent_age, self.name) == (other.rating, other.apparent_age, other.name)
    def __lt__(self, other):
        if not isinstance(other, Wizard):
            return NotImplemented
        return (self.rating, self.apparent_age, self.name) < (other.rating, other.apparent_age, other.name)
    def __le__(self, other):
        return self < other or self == other
    def __gt__(self, other):
        return not self <= other
    def __ge__(self, other):
        return not self < other
    def __ne__(self, other):
        return not self == other
if __name__ == "__main__":
    wiz = Wizard("Гари Поттер", 75, 45)
    print(wiz)
    wiz.change_rating(20)
    print("После увеличения рейтинга на 20:", wiz)
    wiz.change_rating(-15)
    print("После уменьшения рейтинга на 15:", wiz)
    wiz += "magic"
    print("После добавления 'magic':", wiz)
    result = wiz(100)
    print("Вызов со 100:", result)
    wiz2 = Wizard("Асцендио ", 80, 50)
    print("\nСравнение:")
    print("wiz == wiz2:", wiz == wiz2)
    print("wiz < wiz2:", wiz < wiz2)
    print("wiz > wiz2:", wiz > wiz2)