class Worker:
    def __init__(self, name, position, experience):
        self.name = name
        self.position = position
        self.experience = experience
    def _get_experience_string(self):
        if self.experience % 10 == 1 and self.experience % 100 != 11:
            return f"{self.experience} год"
        elif 2 <= self.experience % 10 <= 4 and (self.experience % 100 < 10 or self.experience % 100 >= 20):
            return f"{self.experience} года"
        else:
            return f"{self.experience} лет"
    def print_info(self):
        exp_str = self._get_experience_string()
        print(f"Имя: {self.name}")
        print(f"Должность: {self.position}")
        print(f"Стаж: {exp_str}")
worker1 = Worker("Алексей", "Программист", 17)
worker1.print_info()
print()
worker2 = Worker("Анна", "Маркетолог", 2)
worker2.print_info()
print()
worker3 = Worker("Дмитрий", "Аналитик", 1)
worker3.print_info()
print()