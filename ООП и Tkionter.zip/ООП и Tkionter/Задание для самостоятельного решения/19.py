class Product:
    def __init__(self, name, store, price):
        self.__name = name
        self.__store = store
        self.__price = price
    @property
    def name(self):
        return self.__name
    @property
    def store(self):
        return self.__store
    @property
    def price(self):
        return self.__price
    def __add__(self, other):
        if isinstance(other, Product):
            return self.__price + other.__price
    def __str__(self):
        return f"Товар: {self.__name}, Магазин: {self.__store}, Цена: {self.__price} руб."
class Warehouse:
    def __init__(self):
        self.__products = []
    def add_product(self, product):
        self.__products.append(product)
    def __getitem__(self, index):
        if 0 <= index < len(self.__products):
            return self.__products[index]
    def find_by_name(self, name):
        for product in self.__products:
            if product.name.lower() == name.lower():
                return product
        return None
    def sort_by_store(self):
        self.__products.sort(key=lambda x: x.store)
    def sort_by_name(self):
        self.__products.sort(key=lambda x: x.name)
    def sort_by_price(self):
        self.__products.sort(key=lambda x: x.price)
    def __str__(self):
        return "\n".join(str(product) for product in self.__products)
if __name__ == "__main__":
    p1 = Product("Ноутбук", "Электросила", 75000)
    p2 = Product("Смартфон", "М.Видео", 45000)
    p3 = Product("Наушники", "Электросила", 12000)
    warehouse = Warehouse()
    warehouse.add_product(p1)
    warehouse.add_product(p2)
    warehouse.add_product(p3)
    print("Все товары на складе:")
    print(warehouse)
    print("\nТовар по индексу 1:")
    print(warehouse[1])
    print("\nПоиск товара 'Наушники':")
    found = warehouse.find_by_name("Наушники")
    print(found if found else "Товар не найден")
    print("\nСортировка по магазину:")
    warehouse.sort_by_store()
    print(warehouse)
    print("\nСортировка по названию товара:")
    warehouse.sort_by_name()
    print(warehouse)
    print("\nСортировка по цене:")
    warehouse.sort_by_price()
    print(warehouse)
    print("\nСумма цен ноутбука и смартфона:")
    print(p1 + p2, "руб.")