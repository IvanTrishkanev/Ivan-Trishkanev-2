class Tomato:
    states = {0: 'Отсутствует', 1: 'Цветение', 2: 'Зеленый', 3: 'Красный'}
    def __init__(self, index):
        self._index = index
        self._state = 0  
    def grow(self):
        if self._state < 3:
            self._state += 1
        print(f'Tomato {self._index} is {Tomato.states[self._state]}')
    def is_ripe(self):
        return self._state == 3
class TomatoBush:
    def __init__(self, num):
        self.tomatoes = [Tomato(i) for i in range(num)]
    def grow_all(self):
        for tomato in self.tomatoes:
            tomato.grow()
    def all_are_ripe(self):
        return all(tomato.is_ripe() for tomato in self.tomatoes)
    def give_away_all(self):
        self.tomatoes = []
class Gardener:
    @staticmethod
    def knowledge_base():
        print('''Справка по садоводству:
1. Помидор проходит 4 стадии роста: Отсутствует, Цветение, Зеленый, Красный.
2. Садовник должен ухаживать за растением, пока все помидоры не созреют.
3. Собирать урожай можно только когда все помидоры красные.''')
    def __init__(self, name, plant):
        self.name = name
        self._plant = plant  
    def work(self):
        print(f'{self.name} ухаживает за растением...')
        self._plant.grow_all()
        print()
    
    def harvest(self):
        if self._plant.all_are_ripe():
            print(f'{self.name} собирает урожай!')
            self._plant.give_away_all()
            return True
        else:
            print('Еще рано собирать урожай! Помидоры не созрели.')
            return False
if __name__ == "__main__":
    Gardener.knowledge_base()
    print('-' * 50)
    tomato_bush = TomatoBush(3) 
    gardener = Gardener('Пригожин', tomato_bush)
    print("Садовник начинает ухаживать за помидорами:")
    gardener.work()
    print("Попытка собрать урожай после первого ухода:")
    gardener.harvest()
    print('-' * 50)
    print("Продолжаем ухаживать за помидорами:")
    for _ in range(2):
        gardener.work()
    print(" Попытка собрать урожай после полного созревания:")
    gardener.harvest()
    print('-' * 50)
    print("Проверка после сбора урожая:")
    print(f"Осталось томатов на кусте: {len(tomato_bush.tomatoes)}")