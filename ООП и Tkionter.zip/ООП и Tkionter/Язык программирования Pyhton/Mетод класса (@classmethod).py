class PhoneWithClassMethods:
    default_color = 'Grey'
    default_model = 'C385'
    
    @classmethod
    def toy_phone(cls, color):
        toy_phone = cls(color, 'ToyPhone', None)
        return toy_phone