from random import randint

class Person:
    count = 0
    
    def __init__(self, c):
        self.id = Person.count
        Person.count += 1
        self.command = c

class Hero(Person):
    def __init__(self, c):
        super().__init__(c)
        self.level = 1
    
    def up_level(self):
        self.level += 1

class Soldier(Person):
    def __init__(self, c):
        super().__init__(c)
        self.my_hero = None
    
    def follow(self, hero):
        self.my_hero = hero.id