class PhoneWithAccess:
    def __init__(self, color):
        self.color = color         
        self._color = color         
        self.__color = color        